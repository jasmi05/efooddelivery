import orderModel from "../models/orderModel.js";
import userModel from "../models/userModel.js";
import Stripe from "stripe";
import dotenv from 'dotenv';

dotenv.config();

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);
const currency = "inr";
const deliveryCharge = 50;
const frontend_URL = 'http://localhost:5175';

// Place an order and create a Stripe session for online payment
export const placeOrder = async (req, res) => {
    try {
        // Log the received order data for debugging
        console.log("Received order data:", req.body);

        // Destructure data from the request body
        const { userId, items, amount, address, paymentMethod } = req.body;

        // Validate input data
        if (!userId || !items || !amount || !address || !paymentMethod) {
            return res.status(400).json({ success: false, message: "Missing required fields" });
        }

        // Create a new order object
        const newOrder = new orderModel({
            userId,
            items,
            amount,
            address,
            paymentMethod,   // Store the payment method (e.g., 'card', 'COD', etc.)
            status: "pending", // Set initial status as "pending"
        });

        // Save the order to the database
        await newOrder.save();

        // Optional: Clear the user's cart after placing an order
        await userModel.findByIdAndUpdate(userId, { cartData: {} });

        // Log the order creation process for debugging
        console.log("Order created successfully:", newOrder);

        // Prepare line items for Stripe checkout
        const line_items = items.map(item => ({
            price_data: {
                currency: currency,
                product_data: { name: item.name },
                unit_amount: item.price * 100, // amount in cents
            },
            quantity: item.quantity,
        }));

        // Add delivery charge as an additional item
        line_items.push({
            price_data: {
                currency: currency,
                product_data: { name: "Delivery Charge" },
                unit_amount: deliveryCharge * 100, // 50 INR as delivery charge, converted to cents
            },
            quantity: 1,
        });

        // Create Stripe checkout session
        const session = await stripe.checkout.sessions.create({
            payment_method_types: ['card'],
            line_items: line_items,
            mode: 'payment',
            success_url: `${frontend_URL}/verify?success=true&orderId=${newOrder._id}`,
            cancel_url: `${frontend_URL}/verify?success=false&orderId=${newOrder._id}`,
        });

        // Send session URL to frontend
        res.json({ success: true, session_url: session.url });
    } catch (error) {
        console.error("Error in creating order and Stripe session", error);
        res.status(500).json({ success: false, message: "Order placement failed" });
    }
};

// List all orders (for admin view)
export const listOrders = async (req, res) => {
    try {
        const orders = await orderModel.find();
        res.json({ success: true, orders });
    } catch (error) {
        console.error("Error retrieving orders:", error);
        res.status(500).json({ success: false, message: "Failed to retrieve orders" });
    }
};

// Update the status of an order
export const updateStatus = async (req, res) => {
    try {
        const { orderId, status } = req.body;
        const updatedOrder = await orderModel.findByIdAndUpdate(orderId, { status }, { new: true });
        res.json({ success: true, order: updatedOrder });
    } catch (error) {
        console.error("Error updating order status:", error);
        res.status(500).json({ success: false, message: "Failed to update status" });
    }
};

// Get a list of orders for a specific user (based on JWT token)
export const userOrders = async (req, res) => {
    try {
        // Extract userId from the decoded JWT token (use middleware to decode token)
        const userId = req.userId; // This should come from authMiddleware
        if (!userId) {
            return res.status(401).json({ success: false, message: "User not authorized" });
        }

        const orders = await orderModel.find({ userId });

        if (orders.length === 0) {
            return res.status(404).json({ success: false, message: "No orders found for this user." });
        }

        res.json({ success: true, orders });
    } catch (error) {
        console.error("Error retrieving user orders:", error);
        res.status(500).json({ success: false, message: "Failed to retrieve orders" });
    }
};

// Verify order after Stripe payment
export const verifyOrder = async (req, res) => {
    try {
        const { success, orderId } = req.query;
        if (!orderId) {
            return res.status(400).json({ success: false, message: "Order ID is required" });
        }

        const status = success === "true" ? "completed" : "failed";
        const updatedOrder = await orderModel.findByIdAndUpdate(orderId, { status }, { new: true });
        res.json({ success: true, order: updatedOrder });
    } catch (error) {
        console.error("Error verifying order:", error);
        res.status(500).json({ success: false, message: "Order verification failed" });
    }
};

// Place an order with Cash on Delivery (COD)
export const placeOrderCod = async (req, res) => {
    try {
        const { userId, items, amount, address } = req.body;

        // Validate input
        if (!userId || !items || !amount || !address) {
            return res.status(400).json({ success: false, message: "Missing required fields" });
        }

        const newOrder = new orderModel({
            userId,
            items,
            amount,
            address,
            status: "pending", // Set initial status as "pending"
            paymentMethod: "cod",
        });
        await newOrder.save();

        // Clear user's cart after order placement
        await userModel.findByIdAndUpdate(userId, { cartData: {} });

        res.json({ success: true, message: "Order placed successfully with COD" });
    } catch (error) {
        console.error("Error placing COD order:", error);
        res.status(500).json({ success: false, message: "COD order placement failed" });
    }
};
